from django.shortcuts import render
import joblib  # For loading ML models
import numpy as np

# Load the trained CatBoost model
cat_model = joblib.load(r"C:\Users\Abhii\Music\Crop_Recommendataion\FRONTEND\cat_model.pkl")

# Label encoding for crops
crop_dict = {
    0: "Bajra", 1: "Barley", 2: "Chilli", 3: "Citrus", 4: "Coriander", 
    5: "Cotton", 6: "Cumin", 7: "Fenugreek", 8: "Fennel", 9: "Garlic", 
    10: "Gram", 11: "Guava", 12: "Maize", 13: "Mango", 14: "Mustard", 
    15: "Oilseeds", 16: "Onion", 17: "Opium", 18: "Pomegranate", 
    19: "Pulses", 20: "Sugarcane", 21: "Tomato", 22: "Wheat"
}

# Fertilizer recommendations based on crop type
fertilizer_dict = {
    "Bajra": "Urea, DAP", "Barley": "MOP, NPK", "Chilli": "Organic Compost", 
    "Citrus": "NPK, Micronutrients", "Coriander": "Compost, NPK", "Cotton": "Urea, Superphosphate", 
    "Cumin": "Urea, MOP", "Fenugreek": "DAP, Organic Manure", "Fennel": "NPK, Potash", 
    "Garlic": "Organic Compost, Urea", "Gram": "Superphosphate, MOP", 
    "Guava": "Micronutrients, DAP", "Maize": "Urea, Superphosphate", "Mango": "NPK, Organic Manure", 
    "Mustard": "Urea, DAP", "Oilseeds": "Superphosphate, NPK", "Onion": "Urea, NPK", 
    "Opium": "DAP, Potash", "Pomegranate": "Organic Manure, NPK", "Pulses": "MOP, Superphosphate", 
    "Sugarcane": "Urea, Organic Compost", "Tomato": "NPK, Organic Compost", "Wheat": "DAP, Urea"
}

# Label encoding for soil types
soil_dict = {
    "Alkaline": 0, "Black": 1, "Clay": 2, "Loamy": 3, "Saline": 4, "Sandy": 5
}

# Label encoding for sunlight exposure
sunlight_dict = {
    "Low": 0, "Medium": 1, "High": 2
}

# Label encoding for irrigation frequency
irrigation_dict = {
    "Low": 0, "Medium": 1, "High": 2
}

# Home Page
def home(request):
    return render(request, 'index.html')

# Input Page
def input(request):
    file_name = 'account.txt'
    name = request.POST.get('name')
    password = request.POST.get('password')
    with open(file_name, 'r') as file:
        account_list = [line.split() for line in file]
    for account in account_list:
        if account[0] == name and account[1] == password:
            return render(request, 'input.html')
    return HttpResponse('Wrong Password or Name', content_type='text/plain')

# Prediction Function
def output(request):
    if request.method == 'POST':
        try:
            # Get user inputs
            nitrogen = float(request.POST.get('nitrogen', 0))
            phosphorus = float(request.POST.get('phosphorus', 0))
            potassium = float(request.POST.get('potassium', 0))
            temperature = float(request.POST.get('temperature', 0))
            humidity = float(request.POST.get('humidity', 0))
            ph = float(request.POST.get('ph', 0))
            rainfall = float(request.POST.get('rainfall', 0))
            soil_moisture = float(request.POST.get('soil_moisture', 0))

            # Encode categorical variables
            soil_type = request.POST.get('soil_type', 'Sandy')
            sunlight_exposure = request.POST.get('sunlight_exposure', 'Medium')
            irrigation_frequency = request.POST.get('irrigation_frequency', 'Medium')
            crop_density = float(request.POST.get('crop_density', 0))
            frost_risk = request.POST.get('frost_risk', 'Medium')

            # Categorical encoding (mapping to numbers)
            soil_type_mapping = {"Sandy": 0, "Clayey": 1, "Loamy": 2, "Silty": 3}
            sunlight_exposure_mapping = {"Low": 0, "Medium": 1, "High": 2}
            irrigation_frequency_mapping = {"Low": 0, "Medium": 1, "High": 2}
            frost_risk_mapping = {"Low": 0, "Medium": 1, "High": 2}

            soil_type_encoded = soil_type_mapping.get(soil_type, 0)
            sunlight_exposure_encoded = sunlight_exposure_mapping.get(sunlight_exposure, 1)
            irrigation_frequency_encoded = irrigation_frequency_mapping.get(irrigation_frequency, 1)
            frost_risk_encoded = frost_risk_mapping.get(frost_risk, 1)

            # Prepare input array
            input_features = np.array([[nitrogen, phosphorus, potassium, temperature, humidity, ph, rainfall, 
                                        soil_moisture, soil_type_encoded, sunlight_exposure_encoded, 
                                        irrigation_frequency_encoded, crop_density, frost_risk_encoded]])

            # Predict crop using CatBoost model
            predicted_crop_array = cat_model.predict(input_features)  
            predicted_crop = predicted_crop_array.item()  # Convert numpy array to scalar value

            # Convert numerical prediction back to crop name
            predicted_crop_name = crop_dict.get(predicted_crop, 'Unknown')

            # Get fertilizer recommendation based on crop type
            recommended_fertilizer = fertilizer_dict.get(predicted_crop_name, "No specific recommendation")

            return render(request, 'output.html', {
                'predicted_crop': predicted_crop_name,
                'recommended_fertilizer': recommended_fertilizer
            })

        except Exception as e:
            return render(request, 'output.html', {'error': f"Error: {str(e)}"})

    return render(request, 'input.html')