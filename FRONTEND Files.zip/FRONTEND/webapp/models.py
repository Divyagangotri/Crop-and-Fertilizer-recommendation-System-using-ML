from django.db import models
import numpy as np
import pickle
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

# Load pre-trained models
rf_crop_model_path = "rf_crop_model.pkl"
rf_irrigation_model_path = "rf_irrigation_model.pkl"
xgb_crop_model_path = "xgb_crop_model.pkl"
xgb_irrigation_model_path = "xgb_irrigation_model.pkl"
lgbm_crop_model_path = "lgbm_crop_model.pkl"
lgbm_irrigation_model_path = "lgbm_irrigation_model.pkl"

rf_crop = pickle.load(open(r"C:\Users\User\Music\CROP_ADVICE\FRONTEND\rf_crop_model.pkl", 'rb'))
rf_irrigation = pickle.load(open(r"C:\Users\User\Music\CROP_ADVICE\FRONTEND\rf_irrigation_model.pkl", 'rb'))
xgb_crop = pickle.load(open(r"C:\Users\User\Music\CROP_ADVICE\FRONTEND\xgb_crop_model.pkl", 'rb'))
xgb_irrigation = pickle.load(open(r"C:\Users\User\Music\CROP_ADVICE\FRONTEND\xgb_irrigation_model.pkl", 'rb'))
lgbm_crop = pickle.load(open(r"C:\Users\User\Music\CROP_ADVICE\FRONTEND\lgbm_crop_model.pkl", 'rb'))
lgbm_irrigation = pickle.load(open(r"C:\Users\User\Music\CROP_ADVICE\FRONTEND\lgbm_irrigation_model.pkl", 'rb'))

@csrf_exempt
def predict_crop(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            features = np.array(data['features']).reshape(1, -1)
            model_type = data.get('model', 'xgb')

            if model_type == 'rf':
                prediction = rf_crop.predict(features)[0]
            elif model_type == 'lgbm':
                prediction = lgbm_crop.predict(features)[0]
            else:
                prediction = xgb_crop.predict(features)[0]

            return JsonResponse({"predicted_crop": str(prediction)})
        except Exception as e:
            return JsonResponse({"error": str(e)})
    return JsonResponse({"error": "Invalid request"})

@csrf_exempt
def predict_irrigation(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            crop_type = np.array([data['crop_type']]).reshape(1, -1)
            model_type = data.get('model', 'xgb')

            if model_type == 'rf':
                prediction = rf_irrigation.predict(crop_type)[0]
            elif model_type == 'lgbm':
                prediction = lgbm_irrigation.predict(crop_type)[0]
            else:
                prediction = xgb_irrigation.predict(crop_type)[0]

            return JsonResponse({"recommended_irrigation": str(prediction)})
        except Exception as e:
            return JsonResponse({"error": str(e)})
    return JsonResponse({"error": "Invalid request"})
